import React, { useEffect, useMemo, useState } from 'react'
import { Table, Button, Space } from 'antd'
import { useOutletContext } from 'react-router-dom'
import CrudModal from '../components/CrudModal'
import { load, save, KEY } from '../utils/storage'

const fields = [
  { name: 'name', label: 'Name', rules: [{ required: true }] },
  { name: 'email', label: 'Email', rules: [{ required: true, type: 'email' }] },
  { name: 'phone', label: 'Phone', rules: [{ required: true }] },
]

export default function CustomersPage() {
  const { search } = useOutletContext()
  const [rows, setRows] = useState(() => load(KEY.CUSTOMERS, [
    { key: 'c1', name: 'John Doe', email: 'john@example.com', phone: '9876543210' }
  ]))

  const [open, setOpen] = useState(false)
  const [mode, setMode] = useState('add')
  const [current, setCurrent] = useState(null)

  useEffect(() => save(KEY.CUSTOMERS, rows), [rows])

  // global add
  useEffect(() => {
    function h() { setMode('add'); setCurrent(null); setOpen(true) }
    window.addEventListener('global-add', h)
    return () => window.removeEventListener('global-add', h)
  }, [])

  const filtered = useMemo(() => {
    const q = (search || '').toLowerCase()
    if (!q) return rows
    return rows.filter(r => Object.values(r).join(' ').toLowerCase().includes(q))
  }, [rows, search])

  const columns = [
    { title: 'NAME', dataIndex: 'name' },
    { title: 'EMAIL', dataIndex: 'email' },
    { title: 'PHONE', dataIndex: 'phone' },
    {
      title: 'ACTION', key: 'action', render: (_, r) => (
        <Space>
          <Button onClick={() => { setMode('view'); setCurrent(r); setOpen(true) }}>View</Button>
          <Button onClick={() => { setMode('edit'); setCurrent(r); setOpen(true) }}>Update</Button>
          <Button danger onClick={() => setRows(prev => prev.filter(x => x.key !== r.key))}>Delete</Button>
        </Space>
      )
    }
  ]

  function handleSave(values) {
    if (mode === 'add') setRows(prev => [...prev, { key: Date.now().toString(), ...values }])
    else if (mode === 'edit' && current) setRows(prev => prev.map(x => x.key === current.key ? { ...x, ...values } : x))
    setOpen(false)
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12 }}>
        <Button type="primary" onClick={() => { setMode('add'); setCurrent(null); setOpen(true) }}>Add New</Button>
      </div>

      <Table columns={columns} dataSource={filtered} pagination={{ pageSize: 6 }} />

      <CrudModal open={open} mode={mode} onCancel={() => setOpen(false)} onSave={handleSave} record={current} fields={fields} />
    </div>
  )
}